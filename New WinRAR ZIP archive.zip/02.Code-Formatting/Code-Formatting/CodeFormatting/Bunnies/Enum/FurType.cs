﻿namespace CodeFormatting.Bunnies.Enum
{
    public enum FurType
    {
        NotFluffy, ALittleFluffy, Fluffy, FluffyToTheLimit
    }
}