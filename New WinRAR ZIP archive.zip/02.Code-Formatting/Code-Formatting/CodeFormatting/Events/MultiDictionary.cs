﻿namespace CodeFormatting.Events
{
    using System;

    public class MultiDictionary<T1, T2>
    {
        private bool v;

        public MultiDictionary(bool v)
        {
            this.v = v;
        }

        public void Add(string v, Event newEvent)
        {
                      
        }

        public void Remove(string title)
        {
            throw new NotImplementedException();
        }
    }
}